# Dashboard PCB — revision A

Completed PCB layout: **70 × 50 mm**, two outer copper layers, **no internal copper layers**, nominal 1.6 mm FR-4. Components are fitted on both faces. The XIAO USB-C faces the left edge; the custom USB-A faces the right edge. LED wiring uses the approved 3.5 mm screw-terminal pitch.

## Files

- `dashboard.kicad_pro`, `dashboard.kicad_sch`, `dashboard.kicad_pcb`: editable KiCad 10 project, schematic and finished routing.
- `dashboard.kicad_sym`, `dashboard.pretty`, `sym-lib-table`, `fp-lib-table`: bundled project libraries. Standard KiCad libraries are still required.
- `release/dashboard-revA-gerbers.zip`: copper, mask, silkscreen, paste, outline and Excellon drill files.
- `release/bom.csv`, `release/component-positions.csv`: component list and placement coordinates in millimetres. Bottom-side rotations and machine origin must be checked by the assembler.
- `release/previews`: front/back copper and assembly drawings, schematic, and illustrative 3D views. Some third-party components lack 3D models; those views are not a complete enclosure model.
- `release/checks`: ERC, DRC with schematic parity, source netlist and drill report.

## Verified

KiCad 10.0.6 reports **0 schematic ERC violations, 0 PCB DRC violations, 0 unconnected items, and 0 schematic parity issues**. Existing ignored rule categories remain recorded in the reports; no new rule exclusions were added to obtain these results.

The board contains 37 components, 427 track segments and 52 vias. The outline is 70 × 50 mm. Design settings use 0.15 mm default clearance, 0.20 mm signal tracks, and 0.60/0.30 mm vias. The high-current regulator connections use 0.8–1.2 mm copper paths, with a separate narrow feedback trace sensed at the output capacitor. Ground copper is filled on both faces. Target standard 1 oz copper; no controlled-impedance stackup has been specified.

## Assembly and selected parts

Front: XIAO, all connectors, buzzer and R1–R16. Back: U1/U2, LM2596, inductor, SS34, C1–C4 and R17. C3/C4 are polarized through-hole capacitors mounted on the back. Check their polarity against the back assembly drawing. Small resistors include 0402 and 0603 packages.

| Reference | Selected part / mechanical requirement |
|---|---|
| U1, U2 | Nexperia 74HCT595DB, SSOP-16, 5.3 × 6.2 mm body, 0.65 mm pitch |
| U4 | LM2596S-3.3, TO-263-5 |
| D7 | Vishay SS34-M3/57T, **SMC / DO-214AB** |
| L1 | Bourns SRR1260-330M, 33 µH |
| C3 | Panasonic EEUFR1A681, 680 µF / 10 V, 8 mm body, 3.5 mm lead pitch |
| C4 | Panasonic EEUFR1A221, 220 µF / 10 V, 6.3 mm body, 2.5 mm lead pitch |
| D1–D5 | Phoenix PT-1,5-4-3.5-H footprint, four positions, 3.5 mm pitch |
| D6 | Phoenix PT-1,5-2-3.5-H footprint, two positions, 3.5 mm pitch |
| J2 | SparkFun USB-A SMD female geometry, numeric pad mapping corrected in the local footprint |
| J3 | Original SparkFun 10-position, 3.5 mm removable screw-cage geometry |
| BZ1 | Original polarized buzzer footprint, 14 mm body / 10 mm pin pitch |

The exact USB-A connector, J3 connector/plug and buzzer ordering codes were not supplied. Match their mechanical drawings to the included footprints before ordering the PCB or components. The mating terminal plug and USB cables extend beyond the board edge. No mounting holes were requested or added.

Sources: [Nexperia 74HCT595DB](https://www.nexperia.com/product/74HCT595DB), [Vishay SS34](https://www.vishay.com/docs/88751/ss32.pdf), [TI LM2596](https://www.ti.com/lit/ds/symlink/lm2596.pdf). Capacitor and inductor sources are in `SCHEMATIC_CHANGES.md`.

## Electrical use and prototype checks

- J3 pin 1 is regulated **5 V input**, pin 4 is ground. This board is not a direct vehicle-battery input design.
- The XIAO is powered separately through its own USB-C; its VBUS header is unconnected.
- J2 supplies the requested **custom 3.3 V accessory**, 100–200 mA typical / 500 mA transient. It is labelled **3V3 ONLY** on the PCB.
- J3 pins 2/3 connect to J2 D+/D−. Their routed lengths are about 36.19/33.89 mm, with one via each. These are ordinary signal routes; USB high-speed impedance/compliance has not been qualified.
- Prototype validation remains: startup and load-step response, regulator temperature, LED/buzzer operation, and communications with the actual accessory. Passing ERC/DRC does not establish these hardware behaviours.

Open the project from disk to view the final board. If an older editor window remains open, reload the saved files before making further edits.

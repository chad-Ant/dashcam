# Schematic corrections — 26 September 2026

The design assumes a regulated 5 V input on J3 pin 1, with its return on J3 pin 4. The XIAO is powered separately through its onboard USB-C connector; its VBUS header pad is unused. J2 is deliberately a **custom 3.3 V accessory connector**, not a standard 5 V USB power port. The stated accessory load is 100–200 mA normally and 500 mA transiently.

## Changes

- Kept the I2C connector as J1, renamed the USB-A connector J2, and retained terminal block J3.
- Added power-source flags on the externally supplied 5 V/GND rails and the regulated 3.3 V output.
- Marked unused XIAO D1/VBUS and final shift-register cascade output QH' with no-connect markers.
- Removed the VBUS-only flag and stub; retained an explicit note that the XIAO receives power through its onboard USB-C.
- Removed inappropriate physical footprints from power symbols and flags.
- Raised C1/C2's specified voltage rating to 10 V (100 nF, existing 0603 footprint).
- Replaced C3/C4 with polarized capacitor symbols and matching radial footprints. Positive terminal is pad 1; pad 2 is ground.
- Selected actual power-inductor and bulk-capacitor parts, recorded their manufacturer part numbers and ratings in the schematic, and documented the custom accessory voltage/load.

## Selected power components

| Ref | Component | Manufacturer part | Footprint |
|---|---|---|---|
| C3 | 680 µF, 10 V, ±20%, aluminum electrolytic | Panasonic EEUFR1A681 | Capacitor_THT:CP_Radial_D8.0mm_P3.50mm |
| C4 | 220 µF, 10 V, ±20%, aluminum electrolytic | Panasonic EEUFR1A221 | Capacitor_THT:CP_Radial_D6.3mm_P2.50mm |
| L1 | 33 µH shielded power inductor | Bourns SRR1260-330M | Inductor_SMD:L_Bourns_SRR1260 |

C3 has a specified 950 mA RMS ripple-current rating and 56 mΩ maximum impedance at 100 kHz. C4 has a 455 mA rating and 130 mΩ maximum impedance at 100 kHz. These are impedance specifications, not a guaranteed minimum ESR. L1 has a 3 A RMS rating, 2.8 A typical saturation current at 25% inductance drop, and 60 mΩ maximum DCR. The application remains a 500 mA peak design; the inductor rating does not establish a 3 A rating for the assembled circuit.

Sources: [C3](https://industrial.panasonic.com/ww/products/pt/aluminum-cap-lead/models/EEUFR1A681), [C4](https://industrial.panasonic.com/sa/products/pt/aluminum-cap-lead/models/EEUFR1A221), [L1](https://www.bourns.com/docs/product-datasheets/srr1260.pdf), [LM2596 design guidance](https://www.ti.com/lit/ds/symlink/lm2596.pdf).

## Verification and limits

- KiCad 10.0.6 ERC: zero violations under the existing project settings; rule severities/exclusions were not changed.
- Netlist export: no annotation warning after the connector rename.
- Component-to-component net memberships were unchanged by the power-component replacements and unused-VBUS cleanup.
- Selected replacement footprints exist in the installed KiCad library, and their capacitor lead spacing/body diameter matches the selected parts.
- Rendered schematic checked for polarity, pin connections, reference names and notes.

The PCB is now placed and routed on a 70 × 50 mm, two-copper-layer board. See `PCB_DESIGN.md` for the release files and assembly notes. D1–D6 use the approved 3.5 mm LED terminals; D7 is now a Vishay SS34 in SMC; U1/U2 are specified as Nexperia 74HCT595DB in SSOP-16. The USB-A pad numbers were corrected to match the schematic. Project-specific symbols and third-party footprints are bundled locally.

ERC does not validate regulator stability or transient performance. On the assembled board, verify the 3.3 V output during the 100–200 mA to 500 mA load transition and startup. The USB-A connector, removable 10-pin terminal and buzzer still require matching physical purchasing choices against their footprint drawings.

The original schematic backup is stored at:
`C:\Users\THOMAS\.codex\visualizations\2026\09\26\01a0dbd7-cc36-73a0-b412-1c99219f180f\dashboard-before-fixes.kicad_sch`
